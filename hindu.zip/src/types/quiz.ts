export interface Quiz {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  // Add other quiz properties as needed
}
